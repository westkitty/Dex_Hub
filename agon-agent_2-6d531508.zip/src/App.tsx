import React, { useState, useEffect } from 'react';
import type { Task, SystemStatus as SystemStatusType, VoiceState } from './types';
import { ThemeProvider } from './components/ThemeProvider';
import ThemeSwitcher from './components/ThemeSwitcher';
import KanbanBoard from './components/KanbanBoard';
import VoiceCommand from './components/VoiceCommand';
import SystemStatus from './components/SystemStatus';
import Navigation from './components/Navigation';
import TaskModal from './components/TaskModal';
import QuickActions from './components/QuickActions';
import { useTheme } from './components/ThemeProvider';

const DexHubContent: React.FC = () => {
  const { theme } = useTheme();
  const [currentView, setCurrentView] = useState<'dashboard' | 'analytics' | 'settings'>('dashboard');
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Setup project structure',
      content: 'Initialize the DexHub application with proper folder structure and dependencies.',
      priority: 'high',
      status: 'done',
      createdAt: new Date(Date.now() - 86400000),
      updatedAt: new Date(Date.now() - 86400000),
    },
    {
      id: '2',
      title: 'Implement Kanban board',
      content: 'Create the main task management interface with drag-and-drop functionality.',
      priority: 'high',
      status: 'done',
      createdAt: new Date(Date.now() - 43200000),
      updatedAt: new Date(Date.now() - 43200000),
    },
    {
      id: '3',
      title: 'Add voice commands',
      content: 'Integrate voice command interface for hands-free operation.',
      priority: 'medium',
      status: 'doing',
      createdAt: new Date(Date.now() - 21600000),
      updatedAt: new Date(Date.now() - 21600000),
    },
    {
      id: '4',
      title: 'Design multiple themes',
      content: 'Create Cyberpunk, Minimalist, and Retro Terminal visual styles.',
      priority: 'medium',
      status: 'doing',
      createdAt: new Date(Date.now() - 10800000),
      updatedAt: new Date(Date.now() - 10800000),
    },
    {
      id: '5',
      title: 'Test system integration',
      content: 'Verify connection to Big Mac backend and device pairing functionality.',
      priority: 'low',
      status: 'todo',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]);

  const [systemStatus, setSystemStatus] = useState<SystemStatusType>({
    backendConnected: true,
    devicePaired: false,
  });

  const [voiceState, setVoiceState] = useState<VoiceState>({
    isListening: false,
    isProcessing: false,
  });

  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Simulate system status changes
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemStatus(prev => ({
        ...prev,
        devicePaired: Math.random() > 0.7, // 30% chance of being paired
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const handleToggleVoice = () => {
    if (voiceState.isListening) {
      setVoiceState({ isListening: false, isProcessing: true });
      // Simulate processing
      setTimeout(() => {
        setVoiceState({
          isListening: false,
          isProcessing: false,
          lastCommand: 'Create new task: "Review code changes"'
        });
      }, 2000);
    } else {
      setVoiceState({ isListening: true, isProcessing: false });
      // Simulate listening timeout
      setTimeout(() => {
        if (voiceState.isListening) {
          handleToggleVoice();
        }
      }, 3000);
    }
  };

  const handleCreateTask = () => {
    const newTask: Task = {
      id: Date.now().toString(),
      title: 'New Task',
      content: 'Task description...',
      priority: 'medium',
      status: 'todo',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setTasks(prev => [...prev, newTask]);
    setEditingTask(newTask);
    setIsModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleSaveTask = (updatedTask: Task) => {
    setTasks(prev => prev.map(task =>
      task.id === updatedTask.id ? updatedTask : task
    ));
  };

  const handleQuickCommand = (command: string) => {
    setVoiceState({ isListening: false, isProcessing: true, lastCommand: command });

    setTimeout(() => {
      switch (command) {
        case 'complete_all_tasks':
          setTasks(prev => prev.map(task =>
            task.status === 'doing' ? { ...task, status: 'done' as const, updatedAt: new Date() } : task
          ));
          break;
        case 'search_tasks':
          // Simulate search - in real app this would open search
          break;
        case 'refresh_status':
          setSystemStatus(prev => ({ ...prev, backendConnected: !prev.backendConnected }));
          break;
      }
      setVoiceState(prev => ({ ...prev, isProcessing: false }));
    }, 1500);
  };

  const getHeaderClasses = () => {
    switch (theme) {
      case 'cyberpunk':
        return 'bg-gray-900 border-b border-cyan-600 text-cyan-300';
      case 'minimalist':
        return 'bg-white border-b border-gray-200 text-gray-900';
      case 'retro':
        return 'bg-black border-b border-green-600 text-green-300';
      default:
        return '';
    }
  };

  const getMainClasses = () => {
    switch (theme) {
      case 'cyberpunk':
        return 'bg-gray-900 text-cyan-400';
      case 'minimalist':
        return 'bg-gray-50 text-gray-900';
      case 'retro':
        return 'bg-black text-green-400';
      default:
        return '';
    }
  };

  if (currentView !== 'dashboard') {
    return (
      <div className={`min-h-screen ${getMainClasses()}`}>
        <header className={`p-6 ${getHeaderClasses()}`}>
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <h1 className="text-3xl font-bold">DexHub</h1>
            <div className="flex items-center gap-4">
              <ThemeSwitcher />
              <Navigation currentView={currentView} onViewChange={setCurrentView} />
            </div>
          </div>
        </header>

        <main className="p-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center py-20">
              <h2 className="text-2xl font-bold mb-4">
                {currentView === 'analytics' ? 'Analytics View' : 'Settings View'}
              </h2>
              <p className={`text-lg ${theme === 'retro' ? 'text-green-500' : theme === 'minimalist' ? 'text-gray-600' : 'text-cyan-500'}`}>
                This view is coming soon! Switch back to Dashboard to see the full DexHub experience.
              </p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${getMainClasses()}`}>
      <header className={`p-6 ${getHeaderClasses()}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-3xl font-bold">DexHub</h1>
          <div className="flex items-center gap-4">
            <ThemeSwitcher />
            <Navigation currentView={currentView} onViewChange={setCurrentView} />
          </div>
        </div>
      </header>

      <main className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* System Status and Voice Command */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <SystemStatus status={systemStatus} />
            <VoiceCommand voiceState={voiceState} onToggleListening={handleToggleVoice} />
          </div>

          {/* Quick Actions */}
          <QuickActions onCreateTask={handleCreateTask} onQuickCommand={handleQuickCommand} />

          {/* Kanban Board */}
          <KanbanBoard
            tasks={tasks}
            onTasksChange={setTasks}
            onEditTask={handleEditTask}
            onCreateTask={handleCreateTask}
          />
        </div>
      </main>

      <TaskModal
        task={editingTask}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveTask}
      />
    </div>
  );
};

function App() {
  return (
    <ThemeProvider>
      <DexHubContent />
    </ThemeProvider>
  );
}

export default App;
