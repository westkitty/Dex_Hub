import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { Task } from '../types';
import { useTheme } from './ThemeProvider';
import { Flag, Clock, Edit } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit }) => {
  const { theme } = useTheme();
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return theme === 'cyberpunk' ? 'text-red-400' :
               theme === 'minimalist' ? 'text-red-600' :
               'text-red-400';
      case 'medium':
        return theme === 'cyberpunk' ? 'text-yellow-400' :
               theme === 'minimalist' ? 'text-orange-600' :
               'text-yellow-400';
      case 'low':
        return theme === 'cyberpunk' ? 'text-green-400' :
               theme === 'minimalist' ? 'text-green-600' :
               'text-green-400';
      default:
        return '';
    }
  };

  const getCardClasses = () => {
    const baseClasses = 'p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-lg';

    if (isDragging) {
      return `${baseClasses} opacity-50 rotate-2 scale-105`;
    }

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border-cyan-600 hover:border-cyan-400 shadow-cyan-400/20 hover:shadow-cyan-400/40`;
      case 'minimalist':
        return `${baseClasses} bg-white border-gray-200 hover:border-blue-300 shadow-gray-200 hover:shadow-blue-200`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border-green-600 hover:border-green-400 shadow-green-400/20 hover:shadow-green-400/40`;
      default:
        return baseClasses;
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={getCardClasses()}
      onClick={() => onEdit(task)}
    >
      <div className="flex items-start justify-between mb-2">
        <h3 className={`font-semibold text-sm leading-tight ${theme === 'retro' ? 'text-green-300' : theme === 'minimalist' ? 'text-gray-900' : 'text-cyan-300'}`}>
          {task.title}
        </h3>
        <div className="flex items-center gap-1">
          <Flag className={`w-3 h-3 ${getPriorityColor(task.priority)}`} />
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(task);
            }}
            className={`p-1 rounded ${theme === 'cyberpunk' ? 'hover:bg-cyan-600' : theme === 'minimalist' ? 'hover:bg-blue-100' : 'hover:bg-green-600'}`}
          >
            <Edit className="w-3 h-3" />
          </button>
        </div>
      </div>

      <p className={`text-xs mb-3 line-clamp-2 ${theme === 'retro' ? 'text-green-500' : theme === 'minimalist' ? 'text-gray-600' : 'text-cyan-500'}`}>
        {task.content}
      </p>

      <div className="flex items-center justify-between text-xs">
        <div className={`flex items-center gap-1 ${theme === 'retro' ? 'text-green-600' : theme === 'minimalist' ? 'text-gray-500' : 'text-cyan-600'}`}>
          <Clock className="w-3 h-3" />
          <span>{new Date(task.createdAt).toLocaleDateString()}</span>
        </div>
        <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)} ${
          theme === 'cyberpunk' ? 'bg-gray-700' :
          theme === 'minimalist' ? 'bg-gray-100' :
          'bg-gray-800'
        }`}>
          {task.priority.toUpperCase()}
        </span>
      </div>
    </div>
  );
};

export default TaskCard;