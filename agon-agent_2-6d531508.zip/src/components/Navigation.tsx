import React from 'react';
import { useTheme } from './ThemeProvider';
import { Home, Settings, BarChart3 } from 'lucide-react';

interface NavigationProps {
  currentView: 'dashboard' | 'analytics' | 'settings';
  onViewChange: (view: 'dashboard' | 'analytics' | 'settings') => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onViewChange }) => {
  const { theme } = useTheme();

  const navItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: <Home className="w-5 h-5" /> },
    { id: 'analytics' as const, label: 'Analytics', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'settings' as const, label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  const getContainerClasses = () => {
    const baseClasses = 'flex gap-2 p-2 rounded-lg border';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border-cyan-600`;
      case 'minimalist':
        return `${baseClasses} bg-white border-gray-200`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border-green-600`;
      default:
        return baseClasses;
    }
  };

  const getButtonClasses = (isActive: boolean) => {
    const baseClasses = 'flex items-center gap-2 px-4 py-2 rounded-lg transition-all';

    if (isActive) {
      switch (theme) {
        case 'cyberpunk':
          return `${baseClasses} bg-cyan-600 text-black shadow-lg shadow-cyan-400/50`;
        case 'minimalist':
          return `${baseClasses} bg-blue-600 text-white shadow-lg`;
        case 'retro':
          return `${baseClasses} bg-green-600 text-black shadow-lg shadow-green-400/50`;
        default:
          return baseClasses;
      }
    } else {
      switch (theme) {
        case 'cyberpunk':
          return `${baseClasses} text-cyan-400 hover:bg-gray-700 hover:text-cyan-300`;
        case 'minimalist':
          return `${baseClasses} text-gray-700 hover:bg-gray-100`;
        case 'retro':
          return `${baseClasses} text-green-400 hover:bg-gray-800 hover:text-green-300`;
        default:
          return baseClasses;
      }
    }
  };

  return (
    <nav className={getContainerClasses()}>
      {navItems.map(item => (
        <button
          key={item.id}
          onClick={() => onViewChange(item.id)}
          className={getButtonClasses(currentView === item.id)}
        >
          {item.icon}
          <span className="text-sm font-medium">{item.label}</span>
        </button>
      ))}
    </nav>
  );
};

export default Navigation;