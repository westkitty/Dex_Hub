import React from 'react';
import { useTheme } from './ThemeProvider';
import type { Theme } from './ThemeProvider';
import { Palette, Zap, Terminal } from 'lucide-react';

const ThemeSwitcher: React.FC = () => {
  const { theme, setTheme } = useTheme();

  const themes: { key: Theme; label: string; icon: React.ReactNode }[] = [
    { key: 'cyberpunk', label: 'Cyberpunk', icon: <Zap className="w-4 h-4" /> },
    { key: 'minimalist', label: 'Minimalist', icon: <Palette className="w-4 h-4" /> },
    { key: 'retro', label: 'Retro Terminal', icon: <Terminal className="w-4 h-4" /> },
  ];

  return (
    <div className="flex gap-2 p-2">
      {themes.map(({ key, label, icon }) => (
        <button
          key={key}
          onClick={() => setTheme(key)}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
            theme === key
              ? themeClasses[theme].active
              : themeClasses[theme].inactive
          }`}
        >
          {icon}
          <span className="text-sm">{label}</span>
        </button>
      ))}
    </div>
  );
};

const themeClasses = {
  cyberpunk: {
    active: 'bg-cyan-600 text-black border border-cyan-400 shadow-lg shadow-cyan-400/50',
    inactive: 'bg-gray-800 text-cyan-400 border border-gray-700 hover:border-cyan-400',
  },
  minimalist: {
    active: 'bg-blue-600 text-white shadow-lg',
    inactive: 'bg-gray-200 text-gray-700 hover:bg-gray-300',
  },
  retro: {
    active: 'bg-green-600 text-black border border-green-400 shadow-lg shadow-green-400/50',
    inactive: 'bg-gray-900 text-green-400 border border-gray-700 hover:border-green-400',
  },
};

export default ThemeSwitcher;