import React, { useState, useEffect } from 'react';
import type { Task } from '../types';
import { useTheme } from './ThemeProvider';
import { X, Save } from 'lucide-react';

interface TaskModalProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Task) => void;
}

const TaskModal: React.FC<TaskModalProps> = ({ task, isOpen, onClose, onSave }) => {
  const { theme } = useTheme();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setContent(task.content);
      setPriority(task.priority);
    }
  }, [task]);

  const handleSave = () => {
    if (!task) return;

    const updatedTask: Task = {
      ...task,
      title,
      content,
      priority,
      updatedAt: new Date(),
    };

    onSave(updatedTask);
    onClose();
  };

  const getModalClasses = () => {
    const baseClasses = 'fixed inset-0 z-50 flex items-center justify-center p-4';

    if (!isOpen) return `${baseClasses} opacity-0 pointer-events-none`;

    return baseClasses;
  };

  const getBackdropClasses = () => {
    const baseClasses = 'absolute inset-0 transition-opacity';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-black/80 backdrop-blur-sm`;
      case 'minimalist':
        return `${baseClasses} bg-gray-900/50 backdrop-blur-sm`;
      case 'retro':
        return `${baseClasses} bg-black/90`;
      default:
        return baseClasses;
    }
  };

  const getContentClasses = () => {
    const baseClasses = 'relative w-full max-w-md p-6 rounded-lg shadow-xl transform transition-all';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border border-cyan-600 shadow-cyan-400/20`;
      case 'minimalist':
        return `${baseClasses} bg-white border border-gray-200 shadow-gray-400/20`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border border-green-600 shadow-green-400/20`;
      default:
        return baseClasses;
    }
  };

  const getInputClasses = () => {
    const baseClasses = 'w-full px-3 py-2 rounded border transition-colors';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-700 border-gray-600 text-cyan-300 placeholder-cyan-500 focus:border-cyan-400 focus:outline-none`;
      case 'minimalist':
        return `${baseClasses} bg-gray-50 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-blue-500 focus:outline-none`;
      case 'retro':
        return `${baseClasses} bg-gray-800 border-gray-600 text-green-300 placeholder-green-500 focus:border-green-400 focus:outline-none`;
      default:
        return baseClasses;
    }
  };

  const getSelectClasses = () => {
    const baseClasses = 'w-full px-3 py-2 rounded border transition-colors';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-700 border-gray-600 text-cyan-300 focus:border-cyan-400 focus:outline-none`;
      case 'minimalist':
        return `${baseClasses} bg-gray-50 border-gray-300 text-gray-900 focus:border-blue-500 focus:outline-none`;
      case 'retro':
        return `${baseClasses} bg-gray-800 border-gray-600 text-green-300 focus:border-green-400 focus:outline-none`;
      default:
        return baseClasses;
    }
  };

  const getButtonClasses = (variant: 'primary' | 'secondary') => {
    const baseClasses = 'px-4 py-2 rounded font-medium transition-all';

    if (variant === 'primary') {
      switch (theme) {
        case 'cyberpunk':
          return `${baseClasses} bg-cyan-600 text-black hover:bg-cyan-500 shadow-lg shadow-cyan-400/50`;
        case 'minimalist':
          return `${baseClasses} bg-blue-600 text-white hover:bg-blue-700 shadow-lg`;
        case 'retro':
          return `${baseClasses} bg-green-600 text-black hover:bg-green-500 shadow-lg shadow-green-400/50`;
        default:
          return baseClasses;
      }
    } else {
      switch (theme) {
        case 'cyberpunk':
          return `${baseClasses} bg-gray-700 text-cyan-400 hover:bg-gray-600 border border-gray-600`;
        case 'minimalist':
          return `${baseClasses} bg-gray-200 text-gray-700 hover:bg-gray-300`;
        case 'retro':
          return `${baseClasses} bg-gray-800 text-green-400 hover:bg-gray-700 border border-gray-600`;
        default:
          return baseClasses;
      }
    }
  };

  if (!task) return null;

  return (
    <div className={getModalClasses()}>
      <div className={getBackdropClasses()} onClick={onClose} />

      <div className={getContentClasses()}>
        <div className="flex items-center justify-between mb-4">
          <h2 className={`text-lg font-bold ${theme === 'retro' ? 'text-green-300' : theme === 'minimalist' ? 'text-gray-900' : 'text-cyan-300'}`}>
            Edit Task
          </h2>
          <button
            onClick={onClose}
            className={`p-1 rounded hover:bg-opacity-20 ${theme === 'cyberpunk' ? 'hover:bg-cyan-400' : theme === 'minimalist' ? 'hover:bg-gray-200' : 'hover:bg-green-400'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className={`block text-sm font-medium mb-1 ${theme === 'retro' ? 'text-green-400' : theme === 'minimalist' ? 'text-gray-700' : 'text-cyan-400'}`}>
              Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={getInputClasses()}
              placeholder="Enter task title..."
            />
          </div>

          <div>
            <label className={`block text-sm font-medium mb-1 ${theme === 'retro' ? 'text-green-400' : theme === 'minimalist' ? 'text-gray-700' : 'text-cyan-400'}`}>
              Content
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={3}
              className={getInputClasses()}
              placeholder="Enter task description..."
            />
          </div>

          <div>
            <label className={`block text-sm font-medium mb-1 ${theme === 'retro' ? 'text-green-400' : theme === 'minimalist' ? 'text-gray-700' : 'text-cyan-400'}`}>
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
              className={getSelectClasses()}
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={handleSave}
            className={getButtonClasses('primary')}
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </button>
          <button
            onClick={onClose}
            className={getButtonClasses('secondary')}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskModal;