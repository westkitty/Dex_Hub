import React from 'react';
import { useTheme } from './ThemeProvider';
import { Plus, Zap, Search, RefreshCw } from 'lucide-react';

interface QuickActionsProps {
  onCreateTask: () => void;
  onQuickCommand: (command: string) => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({ onCreateTask, onQuickCommand }) => {
  const { theme } = useTheme();

  const actions = [
    {
      id: 'create',
      label: 'New Task',
      icon: <Plus className="w-5 h-5" />,
      action: () => onCreateTask(),
    },
    {
      id: 'complete',
      label: 'Complete All',
      icon: <Zap className="w-5 h-5" />,
      action: () => onQuickCommand('complete_all_tasks'),
    },
    {
      id: 'search',
      label: 'Search',
      icon: <Search className="w-5 h-5" />,
      action: () => onQuickCommand('search_tasks'),
    },
    {
      id: 'refresh',
      label: 'Refresh',
      icon: <RefreshCw className="w-5 h-5" />,
      action: () => onQuickCommand('refresh_status'),
    },
  ];

  const getContainerClasses = () => {
    const baseClasses = 'grid grid-cols-2 md:grid-cols-4 gap-3 p-4 rounded-lg border';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border-cyan-600`;
      case 'minimalist':
        return `${baseClasses} bg-white border-gray-200`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border-green-600`;
      default:
        return baseClasses;
    }
  };

  const getButtonClasses = () => {
    const baseClasses = 'flex flex-col items-center gap-2 p-4 rounded-lg transition-all hover:scale-105';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-700 text-cyan-400 border border-gray-600 hover:bg-cyan-600 hover:text-black hover:border-cyan-400 shadow-lg hover:shadow-cyan-400/50`;
      case 'minimalist':
        return `${baseClasses} bg-gray-50 text-gray-700 border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700`;
      case 'retro':
        return `${baseClasses} bg-gray-800 text-green-400 border border-gray-600 hover:bg-green-600 hover:text-black hover:border-green-400 shadow-lg hover:shadow-green-400/50`;
      default:
        return baseClasses;
    }
  };

  return (
    <div className={getContainerClasses()}>
      {actions.map(action => (
        <button
          key={action.id}
          onClick={action.action}
          className={getButtonClasses()}
        >
          {action.icon}
          <span className="text-sm font-medium text-center">{action.label}</span>
        </button>
      ))}
    </div>
  );
};

export default QuickActions;