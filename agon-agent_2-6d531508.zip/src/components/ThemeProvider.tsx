import React, { createContext, useContext, useState } from 'react';
import type { ReactNode } from 'react';

export type Theme = 'cyberpunk' | 'minimalist' | 'retro';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>('cyberpunk');

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <div className={`min-h-screen ${getThemeClasses(theme)}`}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

const getThemeClasses = (theme: Theme): string => {
  switch (theme) {
    case 'cyberpunk':
      return 'bg-gray-900 text-cyan-400 font-mono';
    case 'minimalist':
      return 'bg-gray-50 text-gray-900 font-sans';
    case 'retro':
      return 'bg-black text-green-400 font-mono';
    default:
      return '';
  }
};