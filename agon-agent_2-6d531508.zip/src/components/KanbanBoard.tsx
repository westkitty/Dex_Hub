import React from 'react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import type { DragOverEvent, DragStartEvent } from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import type { Task } from '../types';
import { useTheme } from './ThemeProvider';
import TaskCard from './TaskCard';
import { Plus } from 'lucide-react';

interface KanbanBoardProps {
  tasks: Task[];
  onTasksChange: (tasks: Task[]) => void;
  onEditTask: (task: Task) => void;
  onCreateTask: () => void;
}

const KanbanBoard: React.FC<KanbanBoardProps> = ({
  tasks,
  onTasksChange,
  onEditTask,
  onCreateTask,
}) => {
  const { theme } = useTheme();
  const [activeId, setActiveId] = React.useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const columns = [
    { id: 'todo', title: 'To Do', status: 'todo' as const },
    { id: 'doing', title: 'Doing', status: 'doing' as const },
    { id: 'done', title: 'Done', status: 'done' as const },
  ];

  const getTasksByStatus = (status: string) =>
    tasks.filter(task => task.status === status);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;

    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const activeTask = tasks.find(task => task.id === activeId);
    const overTask = tasks.find(task => task.id === overId);

    if (!activeTask) return;

    // If dropping on a column
    if (columns.some(col => col.id === overId)) {
      const newStatus = columns.find(col => col.id === overId)?.status;
      if (newStatus && activeTask.status !== newStatus) {
        const updatedTasks = tasks.map(task =>
          task.id === activeId
            ? { ...task, status: newStatus, updatedAt: new Date() }
            : task
        );
        onTasksChange(updatedTasks);
      }
      return;
    }

    // If dropping on another task
    if (!overTask) return;

    if (activeTask.status !== overTask.status) {
      const updatedTasks = tasks.map(task =>
        task.id === activeId
          ? { ...task, status: overTask.status, updatedAt: new Date() }
          : task
      );
      onTasksChange(updatedTasks);
    }
  };

  const handleDragEnd = () => {
    setActiveId(null);
  };

  const getColumnClasses = () => {
    const baseClasses = 'flex-1 min-h-[500px] p-4 rounded-lg border-2';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border-cyan-600`;
      case 'minimalist':
        return `${baseClasses} bg-gray-50 border-gray-200`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border-green-600`;
      default:
        return baseClasses;
    }
  };

  const getColumnHeaderClasses = () => {
    switch (theme) {
      case 'cyberpunk':
        return 'text-cyan-300 font-bold text-lg mb-4 border-b border-cyan-600 pb-2';
      case 'minimalist':
        return 'text-gray-900 font-bold text-lg mb-4 border-b border-gray-300 pb-2';
      case 'retro':
        return 'text-green-300 font-bold text-lg mb-4 border-b border-green-600 pb-2';
      default:
        return '';
    }
  };

  const activeTask = activeId ? tasks.find(task => task.id === activeId) : null;

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="flex gap-6 h-full">
        {columns.map(column => (
          <div key={column.id} className={getColumnClasses()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className={getColumnHeaderClasses()}>
                {column.title}
                <span className={`ml-2 text-sm ${theme === 'retro' ? 'text-green-500' : theme === 'minimalist' ? 'text-gray-500' : 'text-cyan-500'}`}>
                  ({getTasksByStatus(column.status).length})
                </span>
              </h2>
              {column.id === 'todo' && (
                <button
                  onClick={onCreateTask}
                  className={`p-2 rounded-lg transition-all ${
                    theme === 'cyberpunk'
                      ? 'bg-cyan-600 text-black hover:bg-cyan-500'
                      : theme === 'minimalist'
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-green-600 text-black hover:bg-green-500'
                  }`}
                >
                  <Plus className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="space-y-3 min-h-[400px]">
              <SortableContext
                items={getTasksByStatus(column.status).map(task => task.id)}
                strategy={verticalListSortingStrategy}
              >
                {getTasksByStatus(column.status).map(task => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onEdit={onEditTask}
                  />
                ))}
              </SortableContext>
            </div>
          </div>
        ))}
      </div>

      <DragOverlay>
        {activeTask ? (
          <div className="rotate-2 scale-105 opacity-90">
            <TaskCard task={activeTask} onEdit={() => {}} />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
};

export default KanbanBoard;