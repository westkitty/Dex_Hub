import React from 'react';
import type { SystemStatus as SystemStatusType } from '../types';
import { useTheme } from './ThemeProvider';
import { Wifi, WifiOff, Smartphone } from 'lucide-react';

interface SystemStatusProps {
  status: SystemStatusType;
}

const SystemStatus: React.FC<SystemStatusProps> = ({ status }) => {
  const { theme } = useTheme();

  const getContainerClasses = () => {
    const baseClasses = 'flex items-center gap-6 p-3 rounded-lg';

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border border-cyan-600`;
      case 'minimalist':
        return `${baseClasses} bg-white border border-gray-200`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border border-green-600`;
      default:
        return baseClasses;
    }
  };

  const getIndicatorClasses = (isActive: boolean) => {
    if (isActive) {
      switch (theme) {
        case 'cyberpunk':
          return 'text-cyan-400';
        case 'minimalist':
          return 'text-green-600';
        case 'retro':
          return 'text-green-400';
        default:
          return 'text-green-500';
      }
    } else {
      switch (theme) {
        case 'cyberpunk':
          return 'text-red-400';
        case 'minimalist':
          return 'text-red-600';
        case 'retro':
          return 'text-red-400';
        default:
          return 'text-red-500';
      }
    }
  };

  const getTextClasses = () => {
    switch (theme) {
      case 'cyberpunk':
        return 'text-cyan-300';
      case 'minimalist':
        return 'text-gray-900';
      case 'retro':
        return 'text-green-300';
      default:
        return '';
    }
  };

  return (
    <div className={getContainerClasses()}>
      <div className="flex items-center gap-2">
        {status.backendConnected ? (
          <Wifi className={`w-5 h-5 ${getIndicatorClasses(true)}`} />
        ) : (
          <WifiOff className={`w-5 h-5 ${getIndicatorClasses(false)}`} />
        )}
        <div>
          <div className={`text-sm font-medium ${getTextClasses()}`}>Big Mac</div>
          <div className={`text-xs ${getIndicatorClasses(status.backendConnected)}`}>
            {status.backendConnected ? 'Connected' : 'Disconnected'}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Smartphone className={`w-5 h-5 ${getIndicatorClasses(status.devicePaired)} ${!status.devicePaired ? 'opacity-50' : ''}`} />
        <div>
          <div className={`text-sm font-medium ${getTextClasses()}`}>Device</div>
          <div className={`text-xs ${getIndicatorClasses(status.devicePaired)}`}>
            {status.devicePaired ? 'Paired' : 'Unpaired'}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemStatus;