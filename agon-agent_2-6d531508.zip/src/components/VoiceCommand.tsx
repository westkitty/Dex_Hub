import React, { useState, useEffect } from 'react';
import type { VoiceState } from '../types';
import { useTheme } from './ThemeProvider';
import { Mic, Volume2 } from 'lucide-react';

interface VoiceCommandProps {
  voiceState: VoiceState;
  onToggleListening: () => void;
}

const VoiceCommand: React.FC<VoiceCommandProps> = ({ voiceState, onToggleListening }) => {
  const { theme } = useTheme();
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    if (voiceState.isListening || voiceState.isProcessing) {
      const interval = setInterval(() => {
        setPulse(prev => !prev);
      }, 500);
      return () => clearInterval(interval);
    }
  }, [voiceState.isListening, voiceState.isProcessing]);

  const getContainerClasses = () => {
    const baseClasses = 'flex items-center gap-4 p-4 rounded-lg border-2 transition-all';

    if (voiceState.isListening || voiceState.isProcessing) {
      switch (theme) {
        case 'cyberpunk':
          return `${baseClasses} bg-gray-800 border-cyan-400 shadow-lg shadow-cyan-400/50`;
        case 'minimalist':
          return `${baseClasses} bg-blue-50 border-blue-300 shadow-lg shadow-blue-300/50`;
        case 'retro':
          return `${baseClasses} bg-gray-900 border-green-400 shadow-lg shadow-green-400/50`;
        default:
          return baseClasses;
      }
    }

    switch (theme) {
      case 'cyberpunk':
        return `${baseClasses} bg-gray-800 border-gray-700 hover:border-cyan-400`;
      case 'minimalist':
        return `${baseClasses} bg-gray-50 border-gray-200 hover:border-blue-300`;
      case 'retro':
        return `${baseClasses} bg-gray-900 border-gray-700 hover:border-green-400`;
      default:
        return baseClasses;
    }
  };

  const getStatusText = () => {
    if (voiceState.isProcessing) return 'Processing command...';
    if (voiceState.isListening) return 'Listening...';
    return 'Voice command ready';
  };

  const getStatusColor = () => {
    if (voiceState.isProcessing) return theme === 'cyberpunk' ? 'text-yellow-400' : theme === 'minimalist' ? 'text-orange-600' : 'text-yellow-400';
    if (voiceState.isListening) return theme === 'cyberpunk' ? 'text-cyan-400' : theme === 'minimalist' ? 'text-blue-600' : 'text-green-400';
    return theme === 'retro' ? 'text-green-500' : theme === 'minimalist' ? 'text-gray-600' : 'text-cyan-500';
  };

  return (
    <div className={getContainerClasses()}>
      <button
        onClick={onToggleListening}
        className={`p-3 rounded-full transition-all transform ${
          voiceState.isListening || voiceState.isProcessing
            ? `scale-110 ${pulse ? 'scale-125' : ''}`
            : 'hover:scale-105'
        } ${
          theme === 'cyberpunk'
            ? voiceState.isListening || voiceState.isProcessing
              ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-400/50'
              : 'bg-gray-700 text-cyan-400 hover:bg-cyan-600'
            : theme === 'minimalist'
            ? voiceState.isListening || voiceState.isProcessing
              ? 'bg-blue-500 text-white shadow-lg shadow-blue-400/50'
              : 'bg-gray-200 text-gray-700 hover:bg-blue-100'
            : voiceState.isListening || voiceState.isProcessing
            ? 'bg-green-500 text-black shadow-lg shadow-green-400/50'
            : 'bg-gray-800 text-green-400 hover:bg-green-600'
        }`}
      >
        {voiceState.isListening || voiceState.isProcessing ? (
          <Volume2 className="w-6 h-6" />
        ) : (
          <Mic className="w-6 h-6" />
        )}
      </button>

      <div className="flex-1">
        <div className={`font-medium ${getStatusColor()}`}>
          {getStatusText()}
        </div>
        {voiceState.lastCommand && (
          <div className={`text-sm mt-1 ${theme === 'retro' ? 'text-green-600' : theme === 'minimalist' ? 'text-gray-500' : 'text-cyan-600'}`}>
            Last: "{voiceState.lastCommand}"
          </div>
        )}
      </div>

      {(voiceState.isListening || voiceState.isProcessing) && (
        <div className="flex gap-1">
          <div className={`w-2 h-2 rounded-full animate-pulse ${
            theme === 'cyberpunk' ? 'bg-cyan-400' : theme === 'minimalist' ? 'bg-blue-500' : 'bg-green-400'
          }`} style={{ animationDelay: '0ms' }} />
          <div className={`w-2 h-2 rounded-full animate-pulse ${
            theme === 'cyberpunk' ? 'bg-cyan-400' : theme === 'minimalist' ? 'bg-blue-500' : 'bg-green-400'
          }`} style={{ animationDelay: '150ms' }} />
          <div className={`w-2 h-2 rounded-full animate-pulse ${
            theme === 'cyberpunk' ? 'bg-cyan-400' : theme === 'minimalist' ? 'bg-blue-500' : 'bg-green-400'
          }`} style={{ animationDelay: '300ms' }} />
        </div>
      )}
    </div>
  );
};

export default VoiceCommand;