export interface Task {
  id: string;
  title: string;
  content: string;
  priority: 'low' | 'medium' | 'high';
  status: 'todo' | 'doing' | 'done';
  createdAt: Date;
  updatedAt: Date;
}

export interface SystemStatus {
  backendConnected: boolean;
  devicePaired: boolean;
}

export interface VoiceState {
  isListening: boolean;
  isProcessing: boolean;
  lastCommand?: string;
}