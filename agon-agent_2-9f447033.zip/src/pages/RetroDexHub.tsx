import DexHubLayout from "../shared/DexHubLayout";

export default function RetroDexHub() {
  return <DexHubLayout theme="retro" />;
}
