import DexHubLayout from "../shared/DexHubLayout";

export default function MinimalDexHub() {
  return <DexHubLayout theme="minimal" />;
}
