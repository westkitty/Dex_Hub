import { Link, useLocation } from "react-router-dom";

const variants = [
  { path: "/", label: "Cyberpunk", code: "CY" },
  { path: "/minimal", label: "Minimal", code: "MN" },
  { path: "/retro", label: "Retro", code: "RT" },
];

export default function ThemeSwitcher() {
  const location = useLocation();

  return (
    <div className="fixed inset-x-0 bottom-3 flex justify-center px-3">
      <div className="inline-flex items-center gap-1 rounded-full border border-slate-800/60 bg-black/60 px-1.5 py-1 text-[11px] text-slate-200 shadow-lg backdrop-blur">
        <span className="mr-1 hidden rounded-full bg-slate-900 px-2 py-0.5 text-[10px] uppercase tracking-wide text-slate-400 sm:inline">
          DexHub concepts
        </span>
        {variants.map((v) => {
          const active = location.pathname === v.path;
          return (
            <Link
              key={v.path}
              to={v.path}
              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 transition ${
                active ? "bg-sky-500 text-slate-950" : "text-slate-300 hover:bg-slate-800/80"
              }`}
            >
              <span className="text-[10px] font-mono">{v.code}</span>
              <span>{v.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
