import { useState } from "react";
import { LayoutDashboard, Settings, Mic, Plus, Server, Smartphone, ChevronRight } from "lucide-react";

export type DexTheme = "cyberpunk" | "minimal" | "retro";

export interface Task {
  id: string;
  title: string;
  content: string;
  priority: "Low" | "Medium" | "High";
  status: "To Do" | "Doing" | "Done";
}

const seedTasks: Task[] = [
  { id: "1", title: "Plan DexHub layout", content: "Sketch three UI concepts.", priority: "High", status: "To Do" },
  { id: "2", title: "Sync with Big Mac", content: "Verify backend connection and device pairing.", priority: "Medium", status: "Doing" },
  { id: "3", title: "Voice macro setup", content: "Configure wake phrase and common commands.", priority: "Low", status: "Done" },
];

const statusColumns: Task["status"][] = ["To Do", "Doing", "Done"];

const priorityColors: Record<DexTheme, Record<Task["priority"], string>> = {
  cyberpunk: {
    Low: "bg-cyan-500/10 text-cyan-300 border-cyan-500/40",
    Medium: "bg-fuchsia-500/10 text-fuchsia-300 border-fuchsia-500/40",
    High: "bg-amber-500/10 text-amber-300 border-amber-500/40",
  },
  minimal: {
    Low: "bg-slate-100 text-slate-600 border-slate-200",
    Medium: "bg-sky-50 text-sky-700 border-sky-200",
    High: "bg-rose-50 text-rose-700 border-rose-200",
  },
  retro: {
    Low: "bg-emerald-900 text-emerald-200 border-emerald-400/60",
    Medium: "bg-amber-900 text-amber-200 border-amber-400/60",
    High: "bg-red-900 text-red-200 border-red-400/60",
  },
};

const shellBgByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 text-slate-50",
  minimal: "bg-slate-50 text-slate-900",
  retro: "bg-[#050d02] text-emerald-100",
};

const chromeByTheme: Record<DexTheme, string> = {
  cyberpunk: "border border-slate-800/80 bg-slate-950/60 backdrop-blur-xl shadow-[0_0_40px_rgba(168,85,247,0.35)]",
  minimal: "border border-slate-200 bg-white shadow-sm",
  retro: "border border-emerald-600/60 bg-black/60 shadow-[0_0_40px_rgba(16,185,129,0.35)]",
};

const accentByTheme: Record<DexTheme, string> = {
  cyberpunk: "from-fuchsia-500 via-cyan-400 to-emerald-400",
  minimal: "from-sky-500 via-sky-400 to-emerald-400",
  retro: "from-emerald-400 via-emerald-300 to-amber-300",
};

const navBgByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-slate-900/80 border-slate-800",
  minimal: "bg-white/80 border-slate-200",
  retro: "bg-black/80 border-emerald-700",
};

const columnBgByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-slate-900/60 border-slate-800/80",
  minimal: "bg-slate-50 border-slate-200",
  retro: "bg-black/40 border-emerald-800/70",
};

const badgeMutedByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-slate-900/80 text-slate-400 border-slate-700/80",
  minimal: "bg-slate-100 text-slate-600 border-slate-200",
  retro: "bg-black/70 text-emerald-400 border-emerald-700/80",
};

const voiceBgByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-gradient-to-r from-fuchsia-500/30 via-cyan-500/20 to-emerald-400/30 border-fuchsia-500/40",
  minimal: "bg-sky-50 border-sky-200",
  retro: "bg-black border-emerald-600",
};

const chipByTheme: Record<DexTheme, string> = {
  cyberpunk: "bg-slate-900/60 border-slate-700 text-slate-300",
  minimal: "bg-slate-50 border-slate-200 text-slate-700",
  retro: "bg-black/70 border-emerald-700 text-emerald-300",
};

function classNames(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

interface DexHubLayoutProps {
  theme: DexTheme;
}

export default function DexHubLayout({ theme }: DexHubLayoutProps) {
  const [view, setView] = useState<"dashboard" | "settings">("dashboard");
  const [tasks, setTasks] = useState<Task[]>(seedTasks);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(seedTasks[0]?.id ?? null);
  const [isListening, setIsListening] = useState(false);
  const [isBigMacOnline, setIsBigMacOnline] = useState(true);
  const [isDevicePaired, setIsDevicePaired] = useState(true);

  const selectedTask = tasks.find((t) => t.id === selectedTaskId) ?? null;

  function updateTask(id: string, updates: Partial<Task>) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  }

  function createTask() {
    const id = Date.now().toString();
    const newTask: Task = {
      id,
      title: "New Task",
      content: "Describe what needs to happen...",
      priority: "Medium",
      status: "To Do",
    };
    setTasks((prev) => [newTask, ...prev]);
    setSelectedTaskId(id);
  }

  function quickCommand(cmd: string) {
    if (cmd === "new-high-priority") {
      const id = Date.now().toString();
      const newTask: Task = {
        id,
        title: "High priority action",
        content: "Clarify the objective and next steps.",
        priority: "High",
        status: "To Do",
      };
      setTasks((prev) => [newTask, ...prev]);
      setSelectedTaskId(id);
    }
    if (cmd === "toggle-bigmac") {
      setIsBigMacOnline((v) => !v);
    }
    if (cmd === "toggle-device") {
      setIsDevicePaired((v) => !v);
    }
  }

  const chrome = chromeByTheme[theme];

  return (
    <div className={classNames("min-h-screen", shellBgByTheme[theme])}>
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-4 px-4 py-6 md:py-8">
        {/* Top bar */}
        <header
          className={classNames(
            "flex items-center justify-between rounded-2xl px-4 py-3 md:px-6 md:py-4 border",
            navBgByTheme[theme]
          )}
        >
          <div className="flex items-center gap-3">
            <div
              className={classNames(
                "flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr text-xs font-semibold tracking-widest uppercase",
                accentByTheme[theme]
              )}
            >
              DH
            </div>
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold md:text-base">
                <span>DexHub</span>
                <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] uppercase tracking-wide opacity-70 md:text-xs">
                  Personal Command Center
                </span>
              </div>
              <p className="text-[11px] text-slate-400 md:text-xs">
                Three visual directions sharing one control surface.
              </p>
            </div>
          </div>

          <nav className="flex items-center gap-2 text-xs md:text-sm">
            <button
              onClick={() => setView("dashboard")}
              className={classNames(
                "inline-flex items-center gap-1 rounded-full border px-3 py-1 font-medium transition",
                view === "dashboard"
                  ? "bg-gradient-to-r from-sky-500 to-emerald-400 text-slate-950 border-transparent"
                  : chipByTheme[theme]
              )}
            >
              <LayoutDashboard className="h-3.5 w-3.5" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => setView("settings")}
              className={classNames(
                "inline-flex items-center gap-1 rounded-full border px-3 py-1 font-medium transition",
                view === "settings"
                  ? "bg-gradient-to-r from-sky-500 to-emerald-400 text-slate-950 border-transparent"
                  : chipByTheme[theme]
              )}
            >
              <Settings className="h-3.5 w-3.5" />
              <span>Settings</span>
            </button>
          </nav>
        </header>

        {/* Main content */}
        <main className="grid flex-1 gap-4 md:grid-cols-[minmax(0,2fr)_minmax(0,1.3fr)]">
          {/* Left side: Kanban + system status */}
          <section className={classNames("flex flex-col gap-3 rounded-2xl p-3 md:p-4", chrome)}>
            {/* Status + quick actions */}
            <div className="flex flex-wrap items-center gap-2 md:gap-3">
              <div className="flex flex-wrap items-center gap-2 md:gap-3">
                {/* Big Mac status */}
                <div
                  className={classNames(
                    "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium md:text-xs",
                    badgeMutedByTheme[theme]
                  )}
                >
                  <span
                    className={classNames(
                      "h-1.5 w-1.5 rounded-full",
                      isBigMacOnline ? "bg-emerald-400" : "bg-rose-500"
                    )}
                  />
                  <Server className="h-3.5 w-3.5" />
                  <span>Big Mac</span>
                  <span className="opacity-70">
                    {isBigMacOnline ? "Connected" : "Offline"}
                  </span>
                </div>

                {/* Device status */}
                <div
                  className={classNames(
                    "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium md:text-xs",
                    badgeMutedByTheme[theme]
                  )}
                >
                  <span
                    className={classNames(
                      "h-1.5 w-1.5 rounded-full",
                      isDevicePaired ? "bg-emerald-400" : "bg-amber-400"
                    )}
                  />
                  <Smartphone className="h-3.5 w-3.5" />
                  <span>Device</span>
                  <span className="opacity-70">
                    {isDevicePaired ? "Paired" : "Not paired"}
                  </span>
                </div>
              </div>

              <div className="ml-auto flex flex-wrap items-center gap-2 md:gap-3">
                <button
                  onClick={createTask}
                  className={classNames(
                    "inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r px-3 py-1.5 text-xs font-semibold text-slate-950 shadow-sm md:text-sm",
                    accentByTheme[theme]
                  )}
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>New Task</span>
                </button>

                <div className="flex gap-1.5">
                  <button
                    onClick={() => quickCommand("new-high-priority")}
                    className={classNames(
                      "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[11px] font-medium md:text-xs",
                      chipByTheme[theme]
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
                    High-priority card
                  </button>
                  <button
                    onClick={() => quickCommand("toggle-bigmac")}
                    className={classNames(
                      "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[11px] font-medium md:text-xs",
                      chipByTheme[theme]
                    )}
                  >
                    Big Mac
                  </button>
                  <button
                    onClick={() => quickCommand("toggle-device")}
                    className={classNames(
                      "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[11px] font-medium md:text-xs",
                      chipByTheme[theme]
                    )}
                  >
                    Device
                  </button>
                </div>
              </div>
            </div>

            {/* Kanban Omni-View */}
            <div className="mt-1 grid flex-1 gap-2 md:grid-cols-3 md:gap-3">
              {statusColumns.map((status) => (
                <div
                  key={status}
                  className={classNames(
                    "flex min-h-[220px] flex-col rounded-2xl border p-2.5 text-xs md:text-sm",
                    columnBgByTheme[theme]
                  )}
                >
                  <div className="mb-1.5 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-semibold uppercase tracking-wide opacity-80 md:text-xs">
                        {status}
                      </span>
                      <span className="rounded-full bg-black/10 px-1.5 text-[10px] opacity-70">
                        {tasks.filter((t) => t.status === status).length}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        const id = Date.now().toString();
                        const newTask: Task = {
                          id,
                          title: `${status} task`,
                          content: "Fill in the details.",
                          priority: "Medium",
                          status,
                        };
                        setTasks((prev) => [newTask, ...prev]);
                        setSelectedTaskId(id);
                      }}
                      className="rounded-full px-1.5 py-0.5 text-[10px] opacity-70 hover:opacity-100"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex flex-1 flex-col gap-1.5">
                    {tasks
                      .filter((t) => t.status === status)
                      .map((task) => (
                        <button
                          key={task.id}
                          onClick={() => setSelectedTaskId(task.id)}
                          className={classNames(
                            "group flex flex-col items-stretch rounded-xl border px-2 py-1.5 text-left transition",
                            priorityColors[theme][task.priority],
                            selectedTaskId === task.id
                              ? "ring-1 ring-offset-0 ring-sky-400/80"
                              : "opacity-90 hover:opacity-100"
                          )}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="line-clamp-1 text-[11px] font-semibold md:text-xs">
                              {task.title}
                            </span>
                            <span className="rounded-full border border-white/10 px-1.5 text-[9px] uppercase tracking-wide opacity-70">
                              {task.priority}
                            </span>
                          </div>
                          <p className="mt-0.5 line-clamp-2 text-[10px] opacity-80">
                            {task.content}
                          </p>
                        </button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Right side: Voice + details / settings */}
          <section className="flex flex-col gap-3">
            {/* Voice command interface */}
            <div
              className={classNames(
                "relative overflow-hidden rounded-2xl border px-3 py-3 md:px-4 md:py-4",
                voiceBgByTheme[theme]
              )}
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.18em] opacity-80 md:text-xs">
                      Voice Channel
                    </span>
                    <span className="h-[1px] flex-1 bg-white/10" />
                  </div>
                  <p className="mt-1 text-[11px] opacity-80 md:text-xs">
                    Trigger hands-free control, then watch DexHub update in real time.
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[10px] md:text-[11px]">
                    <span className="rounded-full bg-black/10 px-2 py-0.5 opacity-80">
                      Try: "Create task: review DexHub concepts"
                    </span>
                    <span className="rounded-full bg-black/5 px-2 py-0.5 opacity-60">
                      "Move voice macro setup to Doing"
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setIsListening((v) => !v)}
                  className={classNames(
                    "relative inline-flex h-16 w-16 items-center justify-center rounded-full border-2 text-slate-50 shadow-lg transition md:h-20 md:w-20",
                    isListening
                      ? "border-emerald-300 bg-emerald-500/80 shadow-[0_0_25px_rgba(16,185,129,0.9)]"
                      : "border-white/40 bg-black/60 hover:bg-black/80"
                  )}
                >
                  <div
                    className={classNames(
                      "absolute -inset-1 rounded-full opacity-60 blur-md transition",
                      isListening
                        ? "bg-emerald-400/60"
                        : "bg-fuchsia-400/20"
                    )}
                  />
                  <Mic className="relative h-6 w-6" />
                </button>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] md:text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className={classNames(
                      "flex h-1.5 w-1.5 items-center justify-center rounded-full",
                      isListening ? "bg-emerald-400" : "bg-amber-400"
                    )}
                  >
                    <span className="h-1 w-1 rounded-full bg-black/40" />
                  </span>
                  <span className="font-medium">
                    {isListening ? "Listening" : "Standby"}
                  </span>
                  <span className="opacity-70">
                    {isListening ? "Say a command or tap to pause." : "Tap to begin voice input."}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-4 w-8 rounded-full bg-gradient-to-r from-emerald-400/70 via-fuchsia-400/50 to-cyan-300/70 opacity-70" />
                  <span className="h-4 w-8 rounded-full bg-gradient-to-r from-cyan-400/40 via-transparent to-emerald-300/40 opacity-40" />
                </div>
              </div>
            </div>

            {/* Details / settings */}
            <div className={classNames("flex-1 rounded-2xl p-3 md:p-4", chrome)}>
              {view === "dashboard" ? (
                selectedTask ? (
                  <div className="flex h-full flex-col gap-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 text-[11px] md:text-xs">
                        <span className="rounded-full border border-white/10 px-2 py-0.5 font-semibold uppercase tracking-wide opacity-80">
                          Card Detail
                        </span>
                        <ChevronRight className="h-3 w-3 opacity-60" />
                        <span className="opacity-70">Omni-View</span>
                      </div>
                      <select
                        value={selectedTask.priority}
                        onChange={(e) =>
                          updateTask(selectedTask.id, {
                            priority: e.target.value as Task["priority"],
                          })
                        }
                        className={classNames(
                          "rounded-full border px-2 py-1 text-[11px] font-medium outline-none md:text-xs",
                          chipByTheme[theme]
                        )}
                      >
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                      </select>
                    </div>

                    <div className="flex flex-1 flex-col gap-2">
                      <input
                        value={selectedTask.title}
                        onChange={(e) =>
                          updateTask(selectedTask.id, { title: e.target.value })
                        }
                        className="w-full rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-sm font-semibold outline-none placeholder:opacity-40"
                        placeholder="Task title"
                      />
                      <textarea
                        value={selectedTask.content}
                        onChange={(e) =>
                          updateTask(selectedTask.id, { content: e.target.value })
                        }
                        rows={6}
                        className="min-h-[120px] flex-1 resize-none rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-xs outline-none placeholder:opacity-40 md:text-sm"
                        placeholder="Add more context, links, or checklists for this task."
                      />
                      <div className="mt-1 flex flex-wrap items-center justify-between gap-2 text-[11px] md:text-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="opacity-70">Status</span>
                          <select
                            value={selectedTask.status}
                            onChange={(e) =>
                              updateTask(selectedTask.id, {
                                status: e.target.value as Task["status"],
                              })
                            }
                            className={classNames(
                              "rounded-full border px-2 py-1 text-[11px] font-medium outline-none md:text-xs",
                              chipByTheme[theme]
                            )}
                          >
                            {statusColumns.map((status) => (
                              <option key={status} value={status}>
                                {status}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="flex items-center gap-1.5 opacity-70">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                          <span>Autosaved locally</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-xs opacity-70 md:text-sm">
                    <p>No card selected.</p>
                    <p>Select a card in the Omni-View or create a new task.</p>
                  </div>
                )
              ) : (
                <div className="flex h-full flex-col gap-3 text-xs md:text-sm">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="rounded-full border border-white/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide opacity-80">
                        DexHub Settings
                      </span>
                    </div>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="flex flex-col gap-2 rounded-xl border border-white/10 bg-black/10 p-3">
                      <h3 className="text-xs font-semibold md:text-sm">Voice & Input</h3>
                      <label className="flex items-center justify-between gap-2 text-[11px] md:text-xs">
                        <span>Press & hold to talk</span>
                        <input type="checkbox" className="h-3 w-3" defaultChecked />
                      </label>
                      <label className="flex items-center justify-between gap-2 text-[11px] md:text-xs">
                        <span>Show live transcript</span>
                        <input type="checkbox" className="h-3 w-3" defaultChecked />
                      </label>
                      <label className="flex items-center justify-between gap-2 text-[11px] md:text-xs">
                        <span>Confirm destructive commands</span>
                        <input type="checkbox" className="h-3 w-3" defaultChecked />
                      </label>
                    </div>

                    <div className="flex flex-col gap-2 rounded-xl border border-white/10 bg-black/10 p-3">
                      <h3 className="text-xs font-semibold md:text-sm">System Links</h3>
                      <button
                        onClick={() => setIsBigMacOnline((v) => !v)}
                        className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-[11px] md:text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <Server className="h-3.5 w-3.5" />
                          <div className="text-left">
                            <p className="font-medium">Big Mac backend</p>
                            <p className="opacity-70">Toggle simulated connection state.</p>
                          </div>
                        </div>
                        <span
                          className={classNames(
                            "rounded-full px-2 py-0.5 text-[10px] font-medium",
                            isBigMacOnline
                              ? "bg-emerald-500/20 text-emerald-200"
                              : "bg-rose-500/20 text-rose-200"
                          )}
                        >
                          {isBigMacOnline ? "Connected" : "Offline"}
                        </span>
                      </button>

                      <button
                        onClick={() => setIsDevicePaired((v) => !v)}
                        className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-[11px] md:text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <Smartphone className="h-3.5 w-3.5" />
                          <div className="text-left">
                            <p className="font-medium">Companion device</p>
                            <p className="opacity-70">Pair DexHub with your phone or tablet.</p>
                          </div>
                        </div>
                        <span
                          className={classNames(
                            "rounded-full px-2 py-0.5 text-[10px] font-medium",
                            isDevicePaired
                              ? "bg-emerald-500/20 text-emerald-200"
                              : "bg-amber-500/20 text-amber-200"
                          )}
                        >
                          {isDevicePaired ? "Paired" : "Not paired"}
                        </span>
                      </button>
                    </div>
                  </div>

                  <div className="mt-auto flex flex-wrap items-center justify-between gap-2 border-t border-white/5 pt-2 text-[10px] opacity-70 md:text-xs">
                    <span>Prototype controls only – wire to real systems in production.</span>
                    <span>DexHub proto • v0.1</span>
                  </div>
                </div>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
