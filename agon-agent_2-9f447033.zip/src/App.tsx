import { BrowserRouter, Route, Routes } from 'react-router-dom'
import CyberpunkDexHub from './pages/CyberpunkDexHub'
import MinimalDexHub from './pages/MinimalDexHub'
import RetroDexHub from './pages/RetroDexHub'
import ThemeSwitcher from './shared/ThemeSwitcher'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<CyberpunkDexHub />} />
        <Route path="/minimal" element={<MinimalDexHub />} />
        <Route path="/retro" element={<RetroDexHub />} />
      </Routes>
      <ThemeSwitcher />
    </BrowserRouter>
  )
}

export default App
